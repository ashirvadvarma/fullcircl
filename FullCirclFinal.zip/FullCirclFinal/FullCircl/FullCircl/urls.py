from django.conf.urls import url, include
from django.contrib.auth import views as auth_views
from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin

from FullCircl.core import views as core_views


urlpatterns = [
	url(r'^admin/', admin.site.urls),
    url(r'^$', core_views.home, name='home'),
    url(r'^login/$', auth_views.login, {'template_name': 'login.html'}, name='login'),
    url(r'^logout/$', auth_views.logout, {'next_page': 'login'}, name='logout'),
    url(r'^signupStudent/$', core_views.studentSignUp, name='studentSignUp'),
    url(r'^signupRecruiter/$', core_views.recruiterSignUp, name='recruiterSignUp'),
    url(r'^aboutus/$', core_views.base),
    url(r'^bio/$', core_views.matchedBio, name='matchedBio'), 
]
