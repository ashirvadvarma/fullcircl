from django.contrib.auth.decorators import login_required
from django.contrib.auth import login, authenticate
from django.contrib.auth.models import User
from django.shortcuts import render, redirect
import heapq


from FullCircl.core.forms import StudentSignUpForm, RecruiterSignUpForm

priorityDict = {'major' : 1, 'university' : 4, 'education_level' : 2}

clickedID =1

def genStudentPQ():
    heap = []
    return

def genRecruiterPQ():
    return

def base(request):
    return render(request, 'base.html')

def initStudent(myForm):
    user = myForm.save()
    user.refresh_from_db()
    user.studentprofile.birth_date = myForm.cleaned_data.get('birth_date')
    user.studentprofile.bio = myForm.cleaned_data.get('bio')
    user.studentprofile.first_name = myForm.cleaned_data.get('first_name')
    user.studentprofile.last_name = myForm.cleaned_data.get('last_name')
    user.studentprofile.university = myForm.cleaned_data.get('university')
    user.studentprofile.citizen = myForm.cleaned_data.get('citizen')
    user.studentprofile.major = myForm.cleaned_data.get('major')
    user.studentprofile.education_level = myForm.cleaned_data.get('education_level')
    user.studentprofile.is_student = True
    user.studentprofile.is_recruiter = False
    return user

def initRecruiter(myForm):
    user = myForm.save()
    user.refresh_from_db()
    user.recruiterprofile.first_name = myForm.cleaned_data.get('first_name')
    user.recruiterprofile.last_name = myForm.cleaned_data.get('last_name')
    user.recruiterprofile.birth_date = myForm.cleaned_data.get('birth_date')
    user.recruiterprofile.organization = myForm.cleaned_data.get('organization')
    user.recruiterprofile.university = myForm.cleaned_data.get('university')
    user.recruiterprofile.location = myForm.cleaned_data.get('location')
    user.recruiterprofile.industry = myForm.cleaned_data.get('industry')
    user.recruiterprofile.role = myForm.cleaned_data.get('role')
    user.recruiterprofile.preferred_skills = myForm.cleaned_data.get('preferred_skills')
    user.recruiterprofile.sponsorship = myForm.cleaned_data.get('sponsorship')
    user.recruiterprofile.is_student = False
    user.recruiterprofile.is_recruiter = True
    return user

def studentSignUp(request):
    if request.method == 'POST':
        form = StudentSignUpForm(request.POST)
        if form.is_valid():
            user = initStudent(form)
            user.save()
            raw_password = form.cleaned_data.get('password1')
            user = authenticate(username=user.username, password=raw_password)
            login(request, user)
            return redirect('home')
    else:
        form = StudentSignUpForm()
    return render(request, 'studentSignUp.html', {'form': form})

def recruiterSignUp(request):
    if request.method == 'POST':
        form = RecruiterSignUpForm(request.POST)
        if form.is_valid():
            user = initRecruiter(form)
            user.save()
            raw_password = form.cleaned_data.get('password1')
            user = authenticate(username=user.username, password=raw_password)
            login(request, user)
            return redirect('home')
    else:
        form = RecruiterSignUpForm()
    return render(request, 'recruiterSignUp.html', {'form': form})

def matchedBio(request):

    return render(request, 'matchedBio.html', {'newGuy' : newGuy})

@login_required
def home(request):
    #create the priority queue
    #create a dictionary value to pass in the heap

    heap = []

    userList = User.objects.all()
    index = 0

    if hasattr(request.user, 'recruiterprofile'):
        for u in userList:
            if (u.studentprofile.is_student == True):
                print 'lol'
                totalScore = 14

                if (u.studentprofile.major == request.user.recruiterprofile.major):
                    totalScore -= priorityDict['major']

                if (u.studentprofile.university == request.user.recruiterprofile.university):
                    totalScore -= priorityDict['university']

                if (u.studentprofile.education_level == request.user.recruiterprofile.education_level):
                    totalScore -= priorityDict['education_level']

                item = [index, totalScore]
                heapq.heappush(heap, item)

                index += 1



    elif hasattr(request.user, 'studentprofile'):
        for u in userList:
            if (u.recruiterprofile.is_recuiter == True):
                totalScore = 14

                if (u.recruiterprofile.major == request.user.studentprofile.major):
                    totalScore -= priorityDict['major']

                if (u.recruiterprofile.university == request.user.studentprofile.university):
                    totalScore -= priorityDict['university']

                if (u.recruiterprofile.education_level == request.user.studentprofile.education_level):
                    totalScore -= priorityDict['education_level']

                item = [index, totalScore]
                heapq.heappush(heap, item)

                index += 1

    print heap

    result = []
    for h in heap:
        print h
        result.append(User.objects.get(id=h[0]+1))

    return render(request, 'home.html', {'result' : result})





