from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User


class StudentSignUpForm(UserCreationForm):
	first_name = forms.CharField(max_length=40)
	last_name = forms.CharField(max_length=40)
	birth_date = forms.DateField(help_text='Required. Format: YYYY-MM-DD')
	university = forms.CharField(max_length=40)
	citizen = forms.NullBooleanField()
	major = forms.CharField(max_length=40)
	education_level = forms.CharField(max_length=40)
	bio = forms.CharField(max_length=500)

	class Meta:
		model = User
		fields = ('username', 'birth_date', 'password1', 'password2', 'university', 'citizen', 'major', 'education_level', 'first_name', 'last_name', 'bio', )

class RecruiterSignUpForm(UserCreationForm):
	first_name = forms.CharField(max_length=40)
	last_name = forms.CharField(max_length=40)
	birth_date = forms.DateField(help_text='Required. Format: YYYY-MM-DD')
	organization = forms.CharField(max_length=40)
	university = forms.CharField(max_length=40)
	location = forms.CharField(max_length=30)
	industry = forms.CharField(max_length=40)
	role = forms.CharField(max_length=40)
	preferred_skills = forms.CharField(max_length=40)
	sponsorship = forms.NullBooleanField()
	education_level = forms.CharField(max_length=40)
	major = forms.CharField(max_length=40)

	class Meta:
		model = User
		fields = ('username', 'birth_date', 'password1', 'password2', 'organization', 'university', 'location', 'industry', 'role', 'preferred_skills', 'sponsorship', 'first_name', 'last_name', 'education_level', 'major', )


#indices is a list of tuples
#each tuple is in the order (index in database, priority value)







