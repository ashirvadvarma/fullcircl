from __future__ import unicode_literals

from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver


#class Profile(models.Model):
#    user = models.OneToOneField(User, on_delete=models.CASCADE)
#    bio = models.TextField(max_length=500, blank=True)
#    location = models.CharField(max_length=30, blank=True)
#    birth_date = models.DateField(null=True, blank=True)

class StudentProfile(models.Model):
	user = models.OneToOneField(User, on_delete=models.CASCADE)
	bio = models.TextField(max_length=500, blank=True)
	first_name = models.CharField(max_length=40)
	last_name = models.CharField(max_length=40)
	birth_date = models.DateField(null=True, blank=True)
	university = models.CharField(max_length=50)
	citizen = models.NullBooleanField()
	major = models.CharField(max_length=30)
	education_level = models.CharField(max_length=20)
	is_student = models.BooleanField()
	is_recruiter = models.BooleanField()


class RecruiterProfile(models.Model):
	user = models.OneToOneField(User, on_delete=models.CASCADE)
	bio = models.TextField(max_length=500, blank=True)
	first_name = models.CharField(max_length=40)
	last_name = models.CharField(max_length=40)
	birth_date = models.DateField(null=True, blank=True)
	university = models.CharField(max_length=50)
	citizen = models.NullBooleanField()
	major = models.CharField(max_length=30)
	education_level = models.CharField(max_length=20)
	is_student = models.BooleanField()
	is_recruiter = models.BooleanField()
	location = models.CharField(max_length=30)


#@receiver(post_save, sender=User)
#def update_user_profile(sender, instance, created, **kwargs):
#    if created:
#        Profile.objects.create(user=instance)
#    instance.profile.save()

@receiver(post_save, sender=User)
def update_student_profile(sender, instance, created, **kwargs):
	if created:
		StudentProfile.objects.create(user=instance)
	try: 
		instance.studentprofile.save()
	except NameError:
		instance.studentprofile.save()


@receiver(post_save, sender=User)
def update_recruiter_profile(sender, instance, created, **kwargs):
	if created:
		RecruiterProfile.objects.create(user=instance)
	try: 
		instance.recruiterprofile.save()
	except NameError:
		instance.recruiterprofile.save()

